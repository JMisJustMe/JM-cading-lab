import fs from "node:fs";
import { createHash } from "node:crypto";
import { Client } from "@modelcontextprotocol/sdk/client/index.js";
import { StreamableHTTPClientTransport } from "@modelcontextprotocol/sdk/client/streamableHttp.js";

const base = (process.env.JM_PUBLIC_BASE_URL || "").replace(/\/$/, "");
if (!base) throw new Error("JM_PUBLIC_BASE_URL is required");

const EXPECTED_VERSION = "0.2.0-beta.1";
const EXPECTED_SHA = "f788dd3ff38c965fe5b8a7cd20c7b48929fc38a5b2b8a1f552e7b7732275b3fe";
const EXPECTED_BYTES = 24693;
const HAND_BODY_ID = "jm.128-hand-football/v0.7.4";
const HAND_URI = "ui://jm/128-hand-football-v0.7.4-managed-beta.html";
const PROBE_URI = "ui://jm/inline-contact-probe-v0.2.html";

async function fetchOk(path) {
  const response = await fetch(`${base}${path}`, { redirect: "follow" });
  const bytes = new Uint8Array(await response.arrayBuffer());
  if (!response.ok) throw new Error(`${path} returned ${response.status}: ${new TextDecoder().decode(bytes.slice(0, 300))}`);
  return { status: response.status, bytes, text: new TextDecoder().decode(bytes) };
}

const health = JSON.parse((await fetchOk("/health")).text);
if (health.adapterVersion !== EXPECTED_VERSION) throw new Error(`unexpected adapter version ${health.adapterVersion}`);
if (health.channel !== "managed-beta") throw new Error(`unexpected channel ${health.channel}`);
if (health.stableAncestor !== "0.1.2") throw new Error(`unexpected stable ancestor ${health.stableAncestor}`);
if (health.outputSchemaDeclared !== true) throw new Error("health does not confirm output schema");

const exactSource = await fetchOk("/bodies/128-hand-football-v0.7.4/source");
const exactHash = createHash("sha256").update(exactSource.bytes).digest("hex");
if (exactHash !== EXPECTED_SHA) throw new Error(`128 Hand exact-source sha mismatch: ${exactHash}`);
if (exactSource.bytes.byteLength !== EXPECTED_BYTES) throw new Error(`128 Hand source byte mismatch: ${exactSource.bytes.byteLength}`);
if (!exactSource.text.includes("<title>128 Hand Football · v0.7.4</title>")) throw new Error("128 Hand source title mismatch");

const publicPages = {};
for (const path of ["/", "/privacy", "/terms", "/support"]) {
  const result = await fetchOk(path);
  publicPages[path] = { status: result.status, bytes: result.bytes.byteLength };
}

const client = new Client({ name: "jm-inline-contact-managed-beta-proof", version: EXPECTED_VERSION });
const transport = new StreamableHTTPClientTransport(new URL(`${base}/mcp`));
try {
  await client.connect(transport);
  const tools = await client.listTools();
  const byName = new Map(tools.tools.map((tool) => [tool.name, tool]));
  for (const name of ["render-jm-inline-probe", "play-jm-128-hand-football", "jm-inline-status"]) {
    const tool = byName.get(name);
    if (!tool) throw new Error(`${name} not advertised`);
    if (!tool.outputSchema) throw new Error(`${name} outputSchema missing`);
    if (tool.annotations?.readOnlyHint !== true) throw new Error(`${name} readOnlyHint mismatch`);
    if (tool.annotations?.openWorldHint !== false) throw new Error(`${name} openWorldHint mismatch`);
    if (tool.annotations?.destructiveHint !== false) throw new Error(`${name} destructiveHint mismatch`);
  }

  const resources = await client.listResources();
  const byUri = new Map(resources.resources.map((resource) => [resource.uri, resource]));
  if (!byUri.has(PROBE_URI)) throw new Error("managed-beta probe resource missing");
  if (!byUri.has(HAND_URI)) throw new Error("128 Hand resource missing");

  const probeRead = await client.readResource({ uri: PROBE_URI });
  const probeText = probeRead.contents?.[0]?.text || "";
  if (!probeText.includes("INLINE CONTACT PROBE · V0.2")) throw new Error("probe resource body mismatch");
  if (!probeText.includes("JM_INLINE_HOST_ASSIST")) throw new Error("probe repaint assist missing");

  const handRead = await client.readResource({ uri: HAND_URI });
  const handText = handRead.contents?.[0]?.text || "";
  if (!handText.includes("128 HAND FOOTBALL · V0.7.4")) throw new Error("128 Hand carrier body mismatch");
  if (!handText.includes("JM_INLINE_HOST_ASSIST")) throw new Error("128 Hand repaint assist missing");
  if (!handText.includes("PASS") || !handText.includes("SHOOT") || !handText.includes("TACKLE") || !handText.includes("DEFEND")) throw new Error("128 Hand controls missing");

  const probeCall = await client.callTool({ name: "render-jm-inline-probe", arguments: { probeId: "jm.inline-contact-probe/v0.2" } });
  if (probeCall.structuredContent?.probeOnly !== true) throw new Error("probe boundary missing");
  if (probeCall.structuredContent?.chatgptContactProvenByServerCallAlone !== false) throw new Error("probe contact proof boundary mismatch");

  const gameCall = await client.callTool({ name: "play-jm-128-hand-football", arguments: { bodyId: HAND_BODY_ID } });
  const gameReceipt = gameCall.structuredContent || {};
  if (gameReceipt.bodyId !== HAND_BODY_ID) throw new Error("game body id mismatch");
  if (gameReceipt.sourceSha256 !== EXPECTED_SHA) throw new Error("game source sha receipt mismatch");
  if (gameReceipt.sourceBytes !== EXPECTED_BYTES) throw new Error("game source byte receipt mismatch");
  if (gameReceipt.exactSourceRecovered !== true) throw new Error("exact source recovery not declared");
  if (gameReceipt.sourceBytesReturnedUnmodified !== false) throw new Error("host carrier mutation boundary not declared");
  if (gameReceipt.hostRole !== "CARRIER_NOT_SOURCE_AUTHORITY") throw new Error("host/source authority boundary mismatch");
  if (gameReceipt.chatgptContactProvenByServerCallAlone !== false) throw new Error("game contact proof boundary mismatch");

  const statusCall = await client.callTool({ name: "jm-inline-status", arguments: {} });
  const status = statusCall.structuredContent || {};
  if (status.adapterVersion !== EXPECTED_VERSION || status.channel !== "managed-beta") throw new Error("status receipt mismatch");
  if (!Array.isArray(status.bodyIds) || !status.bodyIds.includes(HAND_BODY_ID)) throw new Error("status does not include 128 Hand");

  const receipt = {
    pass: true,
    proofClass: "JM_INLINE_CONTACT_MANAGED_BETA_PUBLIC_SERVER_INTEGRATION",
    baseUrl: base,
    mcpUrl: `${base}/mcp`,
    adapterVersion: EXPECTED_VERSION,
    channel: "managed-beta",
    stableAncestor: "0.1.2",
    exactSource: { bodyId: HAND_BODY_ID, sha256: exactHash, bytes: exactSource.bytes.byteLength, exactSourceRecovered: true },
    publicPages,
    tools: [...byName.keys()].filter((name) => ["render-jm-inline-probe", "play-jm-128-hand-football", "jm-inline-status"].includes(name)),
    resources: [PROBE_URI, HAND_URI],
    hostAssist: "REPAINT_RESIZE_ONLY/v0.1",
    chatgptInlineContactProvenHere: false,
    ownerContactRequiredForNewBody: true,
    truthBoundary: "CI proves server/resource/tool/source integrity only. A new in-chat playable Ding requires owner contact in ChatGPT.",
  };
  fs.writeFileSync("MANAGED_BETA_PUBLIC_PROOF_v0_2_0.json", JSON.stringify(receipt, null, 2) + "\n");
  console.log(JSON.stringify(receipt, null, 2));
} finally {
  await client.close().catch(() => {});
}
